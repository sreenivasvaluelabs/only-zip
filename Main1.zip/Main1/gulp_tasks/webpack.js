const gulp = require('gulp');
const rename = require('gulp-rename');
const gutil = require('gulp-util');
const path = require('path');
const webpack = require('webpack');

const gulpConf = require('../conf/gulp.conf');
const webpackConf = require('../conf/webpack.conf');
const webpackDistConf = require('../conf/webpack-dist.conf');
const webpackDistAppConf = require('../conf/webpack-dist-app.conf');
const browsersync = require('browser-sync');

gulp.task('z-build-step:webpack:dev', done => {
    webpackWrapper(false, webpackConf, done);
});

gulp.task('z-build-step:webpack:watch', done => {
    webpackWrapper(true, webpackConf, done);
});

gulp.task('z-build-step:webpack:dist-app', done => {
    process.env.NODE_ENV = 'production';
    webpackWrapper(false, webpackDistAppConf, done);
});

gulp.task('z-build-step:webpack:dist', done => {
    process.env.NODE_ENV = 'production';
    webpackWrapper(false, webpackDistConf, done);
});

function webpackWrapper(watch, conf, done) {
    const webpackBundler = webpack(conf);

    const webpackChangeHandler = (err, stats) => {
        if (err) {
            gulpConf.errorHandler('Webpack')(err);
        }
        gutil.log(stats.toString({
            colors: true,
            chunks: false,
            hash: false,
            version: false
        }));
        if (done) {
            done();
            done = null;
        } else {
            browsersync.reload();
        }
    };

    if (watch) {
        webpackBundler.watch(200, webpackChangeHandler);
    } else {
        webpackBundler.run(webpackChangeHandler);
    }
}
