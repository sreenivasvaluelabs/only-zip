"use strict";

const path = require("path");
const gulp = require("gulp");
const protractor = require("gulp-protractor");
const typescript = require("gulp-typescript");
const conf = require("../conf/gulp.conf");
const del = require('del');
const browserSync = require("browser-sync");

// Downloads the selenium webdriver
gulp.task("z-build-step:webdriver-update", protractor.webdriver_update);

gulp.task("z-build-step:webdriver-standalone", protractor.webdriver_standalone);

gulp.task("z-build-step:protractor:compile-tests", function () {
    return gulp.src(path.join(conf.paths.e2e, "/**/*.ts"))
        .pipe(typescript())
        .pipe(gulp.dest(path.join(conf.paths.e2e, "compiled")))
});

gulp.task("z-build-step:protractor:compile-tests:cleanup", function () {
    return del([path.join(conf.paths.e2e, "compiled")]);
});

gulp.task("z-build-step:protractor:run-tests", function (done) {
    return gulp.src(path.join(conf.paths.e2e, "compiled/**/*.js"))
        .pipe(protractor.protractor({
            configFile: "protractor.conf.js"
        }))
        .on("error",
        function (err) {
            // Make sure failed tests cause gulp to exit non-zero
            throw err;
        })
        .on("end",
        function () {
            // Close browser sync server
            browserSync.exit();
            done();
        });
});

gulp.task("z-build-step:protractor", gulp.series(
    "z-build-step:protractor:compile-tests:cleanup",
    "z-build-step:protractor:compile-tests",
    "z-build-step:protractor:run-tests",
    "z-build-step:protractor:compile-tests:cleanup"));