export class AuthCredentials {
    public static grantType: string = 'password';
    public static clientId: string = 'daytona';
    public static clientSecret: string = '8A58D6F1E2F447308985FE1E336C0524';
    public static userName: string = 'M95183638_95183638';
    public static password: string = 'password';
}
