import { EnvironmentCollection } from 'mi.estimating';
import { MiEnvironment } from '../miEnvironment';
import { AuthResult } from './authResult';
import { AuthCredentials } from './authCredentials';

export class AuthenticationHandler {
    deferred: ng.IDeferred<AuthResult>;
    $http: ng.IHttpService;

    /** @ngInject */
    constructor(private $injector: ng.auto.IInjectorService, private $rootScope: ng.IRootScopeService, private $q: ng.IQService, private miEnvironment: EnvironmentCollection) {
        this.deferred = this.$q.defer();
    }

    public authenticate(): ng.IPromise<AuthResult> {
        let data = `grant_type=${AuthCredentials.grantType}&client_id=${AuthCredentials.clientId}&client_secret=${AuthCredentials.clientSecret}&username=${AuthCredentials.userName}&password=${AuthCredentials.password}`;
        let config: ng.IRequestShortcutConfig = { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } };

        this.$http = this.$injector.get('$http');

        return this.$http.post(this.miEnvironment.services['authentication'], data, config)
            .then((result) => this.onSuccess(this, result.data, result.status))
            .catch((result) => this.onError(this, result.data, result.status));
    }

    private onSuccess(handler: AuthenticationHandler, result: any, status: number | undefined): ng.IPromise<AuthResult> {
        if (this.$http.defaults.headers) {
            this.$http.defaults.headers.common.Authorization = `${result.token_type} ${result.access_token}`;
        }

        let ret = new AuthResult(result, status || 0);
        this.deferred.resolve(ret);
        return this.deferred.promise;
    }

    private onError(handler: AuthenticationHandler, result: any, status: number): ng.IPromise<AuthResult> {
        let ret = new AuthResult(result, status);
        this.deferred.resolve(ret);
        return this.deferred.promise;
    }
}

