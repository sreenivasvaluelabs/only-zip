/** @ngInject */
function httpConfig($stateProvider: ng.ui.IStateProvider, $urlRouterProvider: angular.ui.IUrlRouterProvider, $locationProvider: ng.ILocationProvider) {
    $locationProvider.html5Mode(true).hashPrefix('!');
    $urlRouterProvider.otherwise('/scorecardview');

    $stateProvider
        .state('app', {
            url: '/',
            component: 'app'
        })
        .state('regionview', {
            url: '/region?regionname&scoreid',
            component: 'regionview',
            resolve: {
                category: ['$stateParams', '$location', function ($stateParams, $location) {
                    if ($stateParams.regionname != undefined)
                    $location.path('/region?regionname');
                    else {   //redirect user to home.
                        alert("violated"); $location.path('/scorecardview');
                    }
                }]
            }
        })
        .state('scorecardview', {
            url: '/scorecardview',
            component: 'scorecardview'
        })
        .state('shopview', {
            url: '/shopview',
            component: 'shopview'
        })
        .state('shopviewkpi', {
            url: '/shopviewkpi',
            component: 'shopviewkpi'
        })
        ;
}

export default httpConfig;
