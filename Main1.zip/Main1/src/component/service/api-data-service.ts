import * as url from 'url';
import { createSecureContext } from 'tls';
export type ServiceConfig = {
    orderby: string;
    skip: number;
    top: number;
    isAscending: boolean;
    webApiUrl: string;
    applyDateLimitation: string;
};

export interface IApiDataService {
    getData<T>(apiUrl: string): ng.IPromise<T>;
    postData<T>(apiUrl: string, data: any): ng.IPromise<T>;
    putData<T>(apiUrl: string, data: any): ng.IPromise<T>;
    delete<T>(apiUrl: string): ng.IPromise<T>;
}

export class ApiDataService implements IApiDataService {

    private sortOrder: 'asc' | 'desc';
    constructor(private $http: ng.IHttpService, private $q: ng.IQService) {

    }

    /********* PUBLIC METHODS *********/
    public getData<T>(apiUrl: string): ng.IPromise<T> {
        let deferred = this.$q.defer<T>();
        this.$http.get<T>(apiUrl)
            .then(
            (response: ng.IHttpPromiseCallbackArg<T>) =>
                this.onSuccess(deferred,
                    response.data))
            .catch((reason) => this.onError(deferred, reason));
        return this.getPromise<T>(deferred);
    }

    public postData<T>(apiUrl: string, data: any): ng.IPromise<T> {
        let deferred = this.$q.defer<T>();
        this.$http.post<T>(apiUrl, data)
            .then((response: ng.IHttpPromiseCallbackArg<T>) => this.onSuccess(deferred, response.data))
            .catch((reason) => this.onError(deferred, reason));
        return this.getPromise<T>(deferred);
    }

    public putData<T>(apiUrl: string, data: any): ng.IPromise<T> {
        let deferred = this.$q.defer<T>();
        this.$http.put<T>(apiUrl, data)
            .then((response: ng.IHttpPromiseCallbackArg<T>) => this.onSuccess(deferred, response.data))
            .catch((reason) => this.onError(deferred, reason));
        return this.getPromise<T>(deferred);
    }

    public delete(apiUrl: string): ng.IPromise<any> {
        let deferred = this.getDeffered();
        this.$http.delete(apiUrl)
            .then((response: ng.IHttpPromiseCallbackArg<any>) => this.onSuccess(deferred, response.data))
            .catch((reason: any) => this.onError(deferred, reason));
        return this.getPromise(deferred);
    }

    /********* PRIVATE METHODS *********/
    // private getConfigForApi(scanConfig: ServiceConfig) {
    //     this.sortOrder = scanConfig.isAscending ? 'asc' : 'desc';
    //     return {
    //         params: {
    //             $orderby: `${scanConfig.orderby} ${this.sortOrder}`,
    //             $skip: scanConfig.skip,
    //             $top: scanConfig.top,
    //             applyDateLimitation: scanConfig.applyDateLimitation
    //         }
    //     };
    // }

    private getPromise<T>(deferred: ng.IDeferred<T>) {
        return deferred.promise;
    }

    private getDeffered<T>(): ng.IDeferred<T> {
        return this.$q.defer<T>();
    }

    private onError<T>(deferred: ng.IDeferred<T>, reason: any) {
        return deferred.reject(reason);
    }

    private onSuccess<T>(deferred: ng.IDeferred<T>, data: any): void {
        deferred.resolve(data);
    }
}
