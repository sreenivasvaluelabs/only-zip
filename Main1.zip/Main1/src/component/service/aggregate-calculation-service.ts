import * as constants from 'constants';
import { IApiDataService, ApiDataService } from './api-data-service';
import { CalculatedMetric, MetricMeta, Claim } from "../model/aggregate-calculation-model";
import { Constants } from '../common/Constants';
import { isNullOrUndefined } from "util";


export interface IVisualizationDataService {
    getSummaryData(key, scoreCardlevel): ng.IPromise<void | Array<CalculatedMetric>>;
    getTeamsData(scoreCardlevel, Userkey, scoreCardTimeFrame): ng.IPromise<void | Array<CalculatedMetric>>;
    getPeersData(scoreCardlevel, Userkey, scoreCardTimeFrame): ng.IPromise<void | Array<CalculatedMetric>>;
    // getMetricClaims(Userkey: number, metricId: number): ng.IPromise<void | Array<Claim>>;
}
export class VisualizationDataService implements IVisualizationDataService {

    constructor(private apiDataService: IApiDataService, private constants: Constants) {

    }
    public getSummaryData(key): ng.IPromise<void | Array<CalculatedMetric>> {
        return this.apiDataService
            .getData(this.constants.BaseUrl + 'visualization/summary/' + key + '/4/4?scorecardid=4')
            .then(data => {
                if (data) {
                    let aggregateData = new Array<CalculatedMetric>();
                    for (let agg of <Array<any>>data) {
                        aggregateData.push({
                            Participant: agg['Participants'],
                            RankScore: agg['RankScore'],
                            MetricId: agg['MetricKey'],
                            MetricName: agg['MetricName'],
                            MetricValue: agg['Value'],
                            MetricType: agg['ValueType'],
                            IsTargetMissed: agg['IsMissedTarget'],
                            Volume: agg['Volume'],
                            MaskPeerNames: agg['MaskPeerNames']
                        });
                    }
                    return aggregateData;
                }
                return null;
            }).catch(error => {
                console.log(error);
            });
    }

    public getTeamsData(scoreCardlevel, Userkey, scoreCardTimeFrame): ng.IPromise<void | Array<any>> {
        return this.apiDataService
            .getData(this.constants.BaseUrl + 'visualization/team/' + scoreCardlevel + '/' + Userkey + '/' + scoreCardTimeFrame + '?scorecardid=4')
            .then(data => {
                if (data) {
                    let resultArr = [];
                    for (let agg in <Array<any>>data) {
                        let aggregateData = new Array<CalculatedMetric>();
                        let aggArray: Array<any> = [];
                        aggArray = data[agg].Value;
                        aggArray.forEach(obj => {
                            aggregateData.push({
                                Participant: data[agg].Key,
                                RankScore: obj['RankScore'],
                                MetricId: obj['MetricKey'],
                                MetricName: obj['MetricName'],
                                MetricValue: obj['Value'],
                                MetricType: obj['ValueType'],
                                IsTargetMissed: obj['IsMissedTarget'],
                                Volume: obj['Volume'],
                                MaskPeerNames: obj['MaskPeerNames']
                            });
                        })
                        resultArr.push(aggregateData);
                    }

                    return resultArr;
                }
                return null;
            }).catch(error => {
                console.log(error);
            });
    }


    public getPeersData(scoreCardlevel, Userkey, scoreCardTimeFrame): ng.IPromise<void | Array<CalculatedMetric>> {

        return this.apiDataService
            .getData(this.constants.BaseUrl + 'visualization/peers/' + scoreCardlevel + '/' + Userkey + '/' + scoreCardTimeFrame + '?scorecardid=4')
            .then(data => {
                if (data) {
                    let resultArr = [];
                    for (let agg in <Array<any>>data) {
                        let aggregateData = new Array<CalculatedMetric>();
                        let aggArray: Array<any> = [];
                        aggArray = data[agg].Value;
                        aggArray.forEach(obj => {
                            aggregateData.push({
                                Participant: data[agg].Key,
                                RankScore: obj['RankScore'],
                                MetricId: obj['MetricKey'],
                                MetricName: obj['MetricName'],
                                MetricValue: obj['Value'],
                                MetricType: obj['ValueType'],
                                IsTargetMissed: obj['IsMissedTarget'],
                                Volume: obj['Volume'],
                                MaskPeerNames: obj['MaskPeerNames']
                            });
                        })
                        resultArr.push(aggregateData);
                    }

                    return resultArr;
                }
                return null;
            }).catch(error => {
                console.log(error);
            });
    }

    public getMetricMetaData(scoreCardlevel, Userkey, scoreCardTimeFrame): ng.IPromise<void | Array<MetricMeta>> {
        return this.apiDataService
            .getData(this.constants.BaseUrl + 'visualization/peers/' + scoreCardlevel + '/' + Userkey + '/' + scoreCardTimeFrame + '?scorecardid=4')
            .then(data => {
                if (data) {
                    let metadata: Array<any> = [
                        {
                            metricname: '% Bumper Repair',
                            metricvalue: '39%',
                            metrictime: 'YTD',
                            target: '52%',
                            peeravg: '51%',
                            companyavg: '52%'
                        },
                        {
                            metricname: '% Parts Required',
                            metricvalue: '22%',
                            metrictime: 'YTD',
                            target: '20%',
                            peeravg: '18%',
                            companyavg: '19%'
                        },
                        {
                            metricname: 'NPS Shop %',
                            metricvalue: '75%',
                            metrictime: 'YTD',
                            target: '82%',
                            peeravg: '85%',
                            companyavg: '88%'
                        }
                    ];
                    let aggregateData = new Array<MetricMeta>();
                    metadata.forEach(agg => {
                        console.log(agg);
                        aggregateData.push({
                            MetricName: agg['metricname'],
                            MetricValue: agg['metricvalue'],
                            MetricTime: agg['metrictime'],
                            Target: agg['target'],
                            PeerAvg: agg['peeravg'],
                            CompanyAvg: agg['companyavg']
                        });
                    });
                    return aggregateData;
                }
                return null;
            }).catch(error => {
                console.log(error);
            });

    }

    public getScoreData(): ng.IPromise<void | Array<CalculatedMetric>> {

        return this.apiDataService
            .getData(this.constants.BaseUrl + 'visualization/score/Userkey/scoreCardlevel/scoreCardTimeFrame?scorecardid=4')
            .then(data => {
                if (data) {
                    let aggregateData = new Array<CalculatedMetric>();
                    for (let agg of <Array<any>>data) {
                        aggregateData.push({
                            Participant: agg['Participants'],
                            RankScore: agg['RankScore'],
                            MetricId: agg['MetricKey'],
                            MetricName: agg['MetricName'],
                            MetricValue: agg['Value'],
                            MetricType: agg['ValueType'],
                            IsTargetMissed: agg['IsMissedTarget'],
                            Volume: agg['Volume'],
                            MaskPeerNames: agg['MaskPeerNames']
                        });
                    }
                    return aggregateData;
                }
                return null;
            }).catch(error => {
                console.log(error);
            });
    }


    public getGraphData(scorecardid, timeFrame, subTimeFrame) {

        let arrayResult: any[] = [];
        let linelabels: any[];
        let linedata: any[];

        if (subTimeFrame === "Quarterly") {
            ;
            linelabels = ["Q3 16", "Q4 16", "Q1 17", "Q2 17"];
            linedata = [65, 59, 80, 81];
        }
        else if (subTimeFrame === "Monthly") {
            linelabels = ["January", "February", "March", "April", "May", "June"];
            linedata = [65, 59, 80, 81, 56, 55];
        }
        else if (subTimeFrame === "Weekly") {
            linelabels = ["Jan W2", "Jan W3", "Jan W4", "Feb W1"];
            linedata = [33, 66, 22, 77];
        }

        arrayResult.push(linelabels);
        arrayResult.push(linedata);

        return arrayResult;


    }


    public getMetricClaims(Userkey: number, metricId: number, timeFrameId: number): ng.IPromise<void | Array<Claim>> {
        return this.apiDataService
            .getData(this.constants.BaseUrl + 'visualization/peers/' + Userkey + '/' + metricId + '/' + timeFrameId + '?scorecardid=4')
            .then(data => {
                if (data) {
                    debugger;
                    let claimData = new Array<Claim>();
                    for (let clm of <Array<any>>data[0].Value) {
                        claimData.push({
                            Id: clm['Id'],
                            ClaimDate: clm['ClaimDate'],
                            Vehicle: clm['Vehicle'],
                            IsMissedTarget: clm['IsMissedTarget'],
                            DateAnchor: clm['DateAnchor'],
                            MetricName: clm['MetricName'],
                            KpiValue: clm['KpiValue'],
                            GrossEstimateAmount: clm['GrossEstimateAmount'],
                            Drivable: isNullOrUndefined(clm['Drivable']) || clm['Drivable'] == false ? 'N' : 'Y',
                            StartDate:clm['StartDate'],
                            EndDate: clm['EndDate'],
                            SurveyId: clm['SurveyId'],
                            SurveyDate: clm['SurveyDate'],
                            SubjectArea: clm['SubjectArea']
                        });
                    }
                    return claimData;
                }
                return null;
            }).catch(error => {
                console.log(error);
            });
    }



}

