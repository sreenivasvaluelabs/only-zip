export class YesDogController {
    dogToShow: string = 'yes';

    public toggleDog() {
        this.dogToShow = this.dogToShow === 'yes' ? 'po' : 'yes';
    }
}

export const YesDog: angular.IComponentOptions = {
    template: require('./core.html'),
    controller: YesDogController
};
