import { BaseContoller } from '../common/base-controller';
import { ICommonEventsService, CommonEventsService } from '../service/common-events-service';
import _ from "lodash";
import { IVisualizationDataService, VisualizationDataService } from '../service/aggregate-calculation-service';
import { Subject } from 'rxjs/Subject';
import { CalculatedMetric, DataRow, MetricMeta } from "../model/aggregate-calculation-model";
import 'angular-ui-grid';
import { ScoreCardDataService } from '../service/scorecard-data-service';
import { ScoreCard } from '../model/scorecard-model';
import { TimeFrame } from '../model/time-frame-model';
import { SelectDuration } from '../common/enums';

export class ShopViewInfoController {
    public currentScoreCard: ScoreCard;
    //Code for loading dropdowns
    public selectDuration: string[] = [SelectDuration[0], SelectDuration[1], SelectDuration[2]];
    public selectRange: string[] = [];
    public selectTimeFrame: string;
    public selectedRange: string;

    public linelabels: string[] = ["J", "F", "M", "A", "M", "J"];
    public linedata: any = [65, 59, 80, 81, 56, 55];

    public popuplinelabels: string[] = ["J", "F", "M", "A", "M", "J"];
    public popuplinedata: any = [65, 59, 80, 81, 56, 55];

    public summaryList: Array<CalculatedMetric> = [];
    public userkey: number = 1;
    public scoreCardlevel: any = 1;
    public scoreCardTimeFrame: string = "4";

    public tabKPI:boolean = true;
    public tabVis:boolean = true;

    public gridOptionsPeers:any;
    public gridApiPeers: any;
    public gridOptionsMetrics:any;
    public gridApiMetrics: any;

    public peersList:any;
    public tempfinalArray:any;
    public fieldsData:any;

    public metricMetaList:any;
    public metricMetaColumnInfo:any;

    public lineoptions: any = {
        maintainAspectRatio:false,
        tooltips: {
            callbacks: {
                label: function (tooltipItem, data) {
                    return data['datasets'][0]['data'][tooltipItem['index']] + '%';
                }
            },
            backgroundColor: 'rgba(13,174,218,1)',
            titleFontSize: 0,
            bodyFontColor: '#fff',
            bodyFontSize: 14,
            displayColors: false
           
        },
        elements: {
            line: {
                tension: 0,
                fill: false,
                backgroundColor: '#0daeda',
                borderColor: '#0daeda',
                borderWidth:2.5
            },
            point: {
                pointStyle: 'circle',
                radius: 3,
                hoverRadius: 3,
                borderColor:'rgba(13, 174, 218,1)',
                backgroundColor:'rgba(13, 174, 218,1)', 
                hoverBackgroundColor: 'rgba(13, 174, 218,1)',
                borderWidth:6             
            }
        },
        scales: {
            xAxes: [{
                gridLines: {
                  display: false,
                  drawBorder: false,
                  color:'#dfdede'
                },
                ticks: {
                  fontSize: 14,
                  fontColor: '#302e2c',
                  fontFamily: "Open Sans"
                }
              }],
              yAxes: [{
                gridLines: {
                  drawBorder: false,
                  color:'#dfdede'
                },
                ticks: {
                  beginAtZero: true,
                  fontSize: 14,
                  fontColor: '#302e2c',
                  min: 0,
                  max: 100,
                  stepSize: 25,
                  padding: 25,
                  fontFamily: "Open Sans"
                }
              }]
           
        }
    };
    public linecolors: any = [{
        pointBackgroundColor: 'rgba(13, 174, 218,1)',
        pointHoverBackgroundColor: 'rgba(13, 174, 218,1)'
    }];

    public pielabels: any = ["Score", "No Score"];
    public piedata: any = [90, 10];
    public pieoptions: any = {
        cutoutPercentage: 87,
        maintainAspectRatio:false,
    };
    public piecolors: any = ["#4fa806", "#9b9b9b"];

    public changedRange() {
        if (this.selectedRange === 'Year To Date' || this.selectedRange === 'Prev 12 months'
            || this.selectedRange === 'Prev 6 months' || this.selectedRange === 'Prev Year') {
            this.selectDuration = [SelectDuration[0], SelectDuration[1]];
        }
        else if (this.selectedRange === 'Quarter To Date' || this.selectedRange === 'Prev 3 months'
            || this.selectedRange === 'Quarter 1, Prev Year' || this.selectedRange === 'Quarter 2, Prev Year'
            || this.selectedRange === 'Quarter 3, Prev Year' || this.selectedRange === 'Quarter 4, Prev Year'
            || this.selectedRange === 'Quarter 1, Current Year' || this.selectedRange === 'Quarter 2, Current Year'
            || this.selectedRange === 'Quarter 3, Current Year') {
            this.selectDuration = [SelectDuration[1], SelectDuration[2]];
        }
        else if (this.selectedRange === 'Month To Date' || this.selectedRange === 'Prev 30 days' || this.selectedRange === 'Prev  month') {
            this.selectDuration = [SelectDuration[2]];
        }
        this.selectTimeFrame = this.selectDuration[0];
        this.changedSubRange();
    }
    public changedSubRange() {
        if (this.selectTimeFrame === "Quarterly") {
            this.linelabels = ["Q3 16", "Q4 16", "Q1 17", "Q2 17"];
            this.linedata = [65, 59, 80, 81];
        }
        else if (this.selectTimeFrame === "Monthly") {
            this.linelabels = ["J", "F", "M", "A", "M", "J"];
            this.linedata = [65, 59, 80, 81, 56, 55];
        }
        else if (this.selectTimeFrame === "Weekly") {
            this.linelabels = ["Jan W2", "Jan W3", "Jan W4", "Feb W1"];
            this.linedata = [33, 66, 22, 77];
        }
    }



    constructor(private visualizationDataService: VisualizationDataService, private scorecardDataService: ScoreCardDataService, private commonEventsService: ICommonEventsService, private $state: ng.ui.IStateService, $stateParams) {
        var vm = this;
        this.getScoreCardData(this.scoreCardTimeFrame);
        this.getSummaryData(this.userkey);

        this.getPeersData(this.userkey, this.scoreCardlevel, this.scoreCardTimeFrame);
        this.getMetricMetaData(this.userkey, this.scoreCardlevel, this.scoreCardTimeFrame);

        vm.gridApiPeers = null;
        vm.gridOptionsPeers = {
            columnDefs: this.fieldsData,
            data: this.tempfinalArray,
            enableColumnMenus: false,
            enableColumnResizing: true,
            enableFiltering: true,
            showTreeExpandNoChildren: true,
            enableVerticalScrollbar: true,
            enableHorizontalScrollbar: true,
            enableSelectAll: false,
            exporterMenuPdf: true,
            exporterCsvFilename: 'UserList.csv',
            enableGridMenu: false,
            exporterMenuCsv: false,
            onRegisterApi: (gridApi) => {
                this.gridApiPeers = gridApi;
                this.gridApiPeers.grid.registerDataChangeCallback(() => {
                    this.gridApiPeers.treeBase.expandAllRows();
                });
            }
        };
        vm.gridOptionsPeers.appScopeProvider = this;
        this.gridOptionsPeers.onRegisterApi = function (gridApi) {
            vm.gridApiPeers = gridApi;
        }

        vm.gridApiMetrics = null;
        vm.gridOptionsMetrics = {
            columnDefs: this.metricMetaColumnInfo,
            data: this.metricMetaList,
            enableColumnMenus: false,
            enableColumnResizing: true,
            enableFiltering: true,
            showTreeExpandNoChildren: true,
            enableVerticalScrollbar: true,
            enableHorizontalScrollbar: true,
            enableSelectAll: false,
            exporterMenuPdf: true,
            exporterCsvFilename: 'UserList.csv',
            enableGridMenu: false,
            exporterMenuCsv: false,
            onRegisterApi: (gridApi) => {
                this.gridApiMetrics = gridApi;
                this.gridApiMetrics.grid.registerDataChangeCallback(() => {
                    this.gridApiMetrics.treeBase.expandAllRows();
                });
            }
        };
        vm.gridOptionsMetrics.appScopeProvider = this;
        this.gridOptionsMetrics.onRegisterApi = function (gridApi) {
            vm.gridApiMetrics = gridApi;
        }
    };

    //Binding TimeFrames Dropdowns
    public getScoreCardData(scorecardid) {
        this.scorecardDataService.getScoreCard(scorecardid).then(scoreData => {
            if (<ScoreCard>scoreData) {
                this.currentScoreCard = <ScoreCard>scoreData;
                for (let timeframe of <Array<TimeFrame>>this.currentScoreCard.TimeFrames) {
                    this.selectRange.push(timeframe.Name);
                }
                this.selectedRange = this.selectRange[0];
                this.changedRange();
            }
        });
    };

    //To get summary data from service
    public getSummaryData(key) {
        this.visualizationDataService.getSummaryData(key).then(summaryData => {
            if (<Array<CalculatedMetric>>summaryData) {
                this.summaryList = [];
                this.summaryList = <Array<CalculatedMetric>>summaryData;
            }
        });
    };

    public getPeersData(userKey, scoreCardLevel, scoreCardTimeFrame) {
        this.visualizationDataService.getPeersData(userKey, scoreCardLevel, scoreCardTimeFrame).then(peersData => {
            if (<Array<CalculatedMetric>>peersData) {
                this.peersList = <Array<CalculatedMetric>>peersData;
                this.fillData(this.peersList);
                this.getColumnDefs(this.peersList);
                this.gridOptionsPeers.columnDefs = this.fieldsData;
                this.gridOptionsPeers.data = this.tempfinalArray;
            }
        });
    };

   
    
    public getMetricMetaData(userKey, scoreCardLevel, scoreCardTimeFrame) {
        this.visualizationDataService.getMetricMetaData(userKey, scoreCardLevel, scoreCardTimeFrame).then(metaData => {
            if (<Array<MetricMeta>>metaData) {
                this.metricMetaList = <Array<MetricMeta>>metaData;
                this.getMetaColumnDefs(this.metricMetaList);
                this.gridOptionsMetrics.columnDefs = this.metricMetaColumnInfo;
                this.gridOptionsMetrics.data = this.metricMetaList;
            }
        });
    };

    //to define the column definition call this function
    public getMetaColumnDefs(aggregatedData: Array<MetricMeta>): Array<any> {
        this.gridOptionsMetrics.columnDefs = [];
        this.gridOptionsMetrics.data = [];
        this.metricMetaColumnInfo = [];

        this.metricMetaColumnInfo.push({
            name: 'Metrics',
            field: 'MetricName',
            headerTooltip: true,
            cellTooltip: true,
            cellClass: function (grid) {
                return 'ui-grid-cell-contents position:absolute mi-color-brand-05 mi-grid-link  noborder'
            },
            cellTemplate: '<div>{{COL_FIELD}}</div>',
            width: 190,
        });
        this.metricMetaColumnInfo.push({
            name: aggregatedData[0].MetricTime,
            field: 'MetricValue',
            headerTooltip: true,
            cellTooltip: true,
            minWidth: 150,
            headerCellClass: "mi-align-center",
            cellTemplate: '<div class="ui-grid-cell-contents mi-align-center">{{COL_FIELD}}</div>',
            cellClass: function (grid) {
                return 'noborder'
            },
        });
        this.metricMetaColumnInfo.push({
            name: 'Target',
            field: 'Target',
            headerTooltip: true,
            cellTooltip: true,
            minWidth: 150,
            headerCellClass: "mi-align-center",
            cellTemplate: '<div class="ui-grid-cell-contents mi-align-center">{{COL_FIELD}}</div>',
            cellClass: function (grid) {
                return 'noborder'
            },
        });
        this.metricMetaColumnInfo.push({
            name: 'Peer Avg',
            field: 'PeerAvg',
            headerTooltip: true,
            cellTooltip: true,
            minWidth: 150,
            headerCellClass: "mi-align-center",
            cellTemplate: '<div class="ui-grid-cell-contents mi-align-center">{{COL_FIELD}}</div>',
            cellClass: function (grid) {
                return 'noborder'
            },
        });
        this.metricMetaColumnInfo.push({
            name: 'Company Avg',
            field: 'CompanyAvg',
            headerTooltip: true,
            cellTooltip: true,
            minWidth: 150,
            headerCellClass: "mi-align-center",
            cellTemplate: '<div class="ui-grid-cell-contents mi-align-center">{{COL_FIELD}}</div>',
            cellClass: function (grid) {
                return 'noborder'
            },
        });
        
        return this.metricMetaColumnInfo;
    };

    //to define the column definition call this function
    public getColumnDefs(aggregatedData: Array<CalculatedMetric>): Array<any> {
        this.gridOptionsPeers.columnDefs = [];
        this.gridOptionsPeers.data = [];
        this.fieldsData = [];

        this.fieldsData.push({
            name: 'Participants',
            field: 'Participant',
            headerTooltip: true,
            cellTooltip: true,
            pinnedLeft: true,
            cellClass: function (grid) {
                return 'boldText ui-grid-cell-contents position:absolute noborder'
            },
            width: 190,
        });

        this.fieldsData.push({
            name: 'Rank/Score',
            field: 'RankScore',
            headerTooltip: true,
            cellTooltip: true,
            pinnedLeft: true,
            width: 100,
            sort: { direction: 'asc' }
        });

        let data:any = aggregatedData[0];
        
        for (let item of <Array<any>>data) {
            this.fieldsData.push({
                name: item['MetricName'],
                field: this.getFieldName(item['MetricName']),
                headerTooltip: true,
                cellTooltip: true,
                minWidth: 150,
                headerCellClass: "mi-align-center",
                cellTemplate: '<div class="ui-grid-cell-contents mi-align-center">{{COL_FIELD}}</div>',
                cellClass: function (grid) {
                    return 'noborder'
                },
            });
        }
        return this.fieldsData;
    };
    
    public fillData(aggregatedData: Array<CalculatedMetric>) {
        this.tempfinalArray = [];
        let participantName: number = 1;
        for (let data of <Array<any>>aggregatedData) {
            let dataObj = {};
            dataObj["Participant"] = data[0]["Participant"];
            dataObj["RankScore"] = data[0]["RankScore"];
            for (let item of <Array<any>>data) {
                let fieldName = this.getFieldName(item['MetricName']);
                if (item['MetricType'] != '$') {
                    dataObj[fieldName] = item['MetricValue'] + item['MetricType'];
                    
                }
                else {
                    dataObj[fieldName] = item['MetricType'] + item['MetricValue'];
                    
                }
            }
            this.tempfinalArray.push(dataObj);
        }
        return this.tempfinalArray;
    };

    public getFieldName(fieldName: string): string {
        let field = '';
        if (fieldName) {
            field = fieldName.replace('%', '');
        }
        return field ? field.replace(/ /g, '') : '';
    };
};


export const ShopView: angular.IComponentOptions = {
    template: require('./shopview.html'),
    controller: ShopViewInfoController
};












