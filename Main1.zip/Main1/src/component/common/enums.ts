export enum HierarchyType { 'Custom', 'Standard', 'Modified', 'Geography' };
export enum ParticipantType { 'NetworkShops', 'OutOfNetWorkShops', 'Staff', 'IA' };
export enum ScoreCardLevel { 'Company', 'Region', 'Division', 'Office', 'Resource' };
export enum CanAllView { 'AllParticipants', 'Custom' };
export enum EmailFrequency {
    Daily = 1,
    Weekly,
    Monthly,
    Quarterly
};
//export enum SubjectArea { None, All, Estimating, Review, Quality, TotalLoss, LDAEstimates, Supplementaryestimates, CycleTime, CSI, Images }
export enum SubjectArea {
    None = 0,
    All = 1 << 0,
    Estimating = All << 1,
    Review = Estimating << 1,
    CycleTime = Review << 1,
    TotalLoss = CycleTime << 1,
    CSI = TotalLoss << 1
}
export enum AnchorType {
    Hierarchy,
    Ownership,
    Date
}
export enum SelectDuration {'Quarterly', 'Monthly', 'Weekly'};
