export interface IConstants {
    BaseUrl: string;
};

export class Constants implements IConstants {
    //BaseUrl = 'http://localhost/Mitchell.Reporting.ScoreCard.Api/api/';
    BaseUrl = 'http://172.22.247.14/Mitchell.Reporting.ScoreCard.Api/api/';
    //BaseUrl = 'http://localhost/Mitchell.Reporting.ScoreCard.Api/api/';
    //BaseUrl ='http://localhost:50831/api/';
    
}