import { SubjectArea } from "./enums";

export function getClaimColumns(subjectArea: SubjectArea): any {
    let key = SubjectArea[subjectArea];
    let claimColumns = [];
    let dataObj = {};
    dataObj['Id'] = 'Claim';
    claimColumns.push(dataObj);
    switch ( key) {
        case 'Estimating' || 'Review':
            dataObj['DateAnchor'] = 'Date Anchor';
            dataObj['Vehicle'] = 'Vehicle info';
            dataObj['KpiValue'] = 'KPI value';
            dataObj['GrossEstimateAmount'] = 'Gross Estimate amount';
            dataObj['Drivable'] = 'Drivable';
            break;
        case "CycleTime":
            dataObj['StartDate'] = 'Start Date';
            dataObj['EndDate'] = 'End Date';
            dataObj['KpiValue'] = 'KPI value';
            dataObj['Drivable'] = 'Drivable';
            break;
        case "CSI":
            dataObj['SurveyId'] = 'Survey ID';
            dataObj['SurveyDate'] = 'Survey Date';
            dataObj['KpiValue'] = 'KPI value';
            dataObj['GrossEstimateAmount'] = 'Gross Estimate amount';
            dataObj['Drivable'] = 'Drivable';
            break;
    }
    
    return claimColumns;
}