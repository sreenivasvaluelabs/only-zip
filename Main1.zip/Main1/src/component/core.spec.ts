import * as angular from 'angular';
import 'angular-mocks';
import 'jasmine';
import { YesDog, YesDogController } from './core.component';

import './core.module';

describe('yesdog component', () => {
    beforeEach(() => {
        angular.mock.module('mi.reporting.scorecard.visualization');
    });

    it('should load a yes dog by default', angular.mock.inject(($rootScope: ng.IRootScopeService
        , $compile: ng.ICompileService
        , $componentController: ng.IComponentControllerService) => {
        const component = $componentController('yesdog', {}, {}) as YesDogController;

        expect(component.dogToShow).toEqual('yes');
    }));

    it('should load allow users to select a better dog', angular.mock.inject(($rootScope: ng.IRootScopeService
        , $compile: ng.ICompileService
        , $componentController: ng.IComponentControllerService) => {
        const component = $componentController('yesdog', {}, {}) as YesDogController;

        component.toggleDog();

        expect(component.dogToShow).toEqual('po');
    }));
});
