import { from } from 'rxjs/observable/from';
import { CommonEventsService } from './service/common-events-service';
import { CommonService } from './service/common-service';
import { ScoreCardDataService } from './service/scorecard-data-service'

import * as angular from 'angular';
import 'angular-material';
import 'angular-gettext';
import 'rxjs';
import 'angular-ui-grid';
import 'angular-chart.js';

import { ApiDataService } from './service/api-data-service';
import { Constants } from './common/constants';
import { AuthenticationHandler } from '../app/components/auth/authenticationHandler';
import { App } from '../app/main/app';
import { RegionView } from '../component/calculated-metrics/aggregate-calculation.component';
import { ShopView } from '../component/shopview/shopview.component';
import { ShopViewKPI } from '../component/shopviewkpi/shopviewkpi.component';
import {ScoreCardView} from '../component/scorecard-view/scorecard-view.Component';
import routesConfig from '../app/routes';
import interceptorConfig from '../app/interceptors';
import componentModule from '../component/core.module';

import './po/en-ca.po';
import './po/en-us.po';
import './po/fr-ca.po';
import { VisualizationDataService } from "./service/aggregate-calculation-service";

export default angular
    .module('mi.scorecard2.0', ['ngMaterial', 'gettext',, 'ui.grid', 'ui.grid.treeView', 'ui.grid.pagination', 'ui.grid.resizeColumns', 'ui.grid.selection', 'ui.grid.expandable', 'ui.grid.exporter', 'ui.grid.autoResize', 'ui.grid.pinning', 'chart.js'])

    .constant('constants', new Constants())
    .service('commonEventsService', CommonEventsService)
    .service('commonService', CommonService)

    .service('apiDataService', ApiDataService)
    .service('visualizationDataService', VisualizationDataService)
    .service('scorecardDataService', ScoreCardDataService)
    .service('authenticationHandler', AuthenticationHandler)
    .config(routesConfig)
    .config(interceptorConfig)    
    .component('app', App)
    .component('regionview',RegionView)
    .component('scorecardview',ScoreCardView)
    .component('shopview', ShopView)
    .component('shopviewkpi', ShopViewKPI)
    .name;
