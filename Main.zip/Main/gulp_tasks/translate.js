const conf = require('../conf/gulp.conf');

const path = require('path');
const gulp = require('gulp');

const shell = require('gulp-shell')
const flatten = require('gulp-flatten');
const extend = require('gulp-extend');
const wrap = require('gulp-wrap');
const rename = require('gulp-rename');

const fsall = require('fs-readdir-recursive');

gulp.task('z-build-step:translate:copy-po-files', copyPoFiles);

function copyPoFiles(done) {
    return gulp.src(path.join(conf.paths.component, '**/*.po'))
        .pipe(rename((path) => {
            let moduleName = path.dirname.split('\\')[0];
            path.basename = conf.rootModuleName + '.' + path.basename;
        }))
        .pipe(flatten())
        .pipe(gulp.dest(path.join(conf.paths.dist, conf.paths.translations)))
        .on('end', done);
}