const conf = require('./gulp.conf');

module.exports = function () {
    return {
        server: {
            baseDir: [
                conf.paths.tmp,
                conf.paths.app,
                conf.paths.assets
            ]
        },
        open: false,
        notify: false
    };
};
