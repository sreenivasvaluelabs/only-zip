import { BaseContoller } from '../common/base-controller';
import { ICommonEventsService, CommonEventsService } from '../service/common-events-service';
import * as stream from 'stream';
import { IScoreCardDataService } from '../service/scorecard-data-service';
import { INavigationStageService, NavigationStageService, Stage } from '../service/navigation-stage-service';
import { IGlobalInfoDataService, GlobalInfoDataService } from '../service/globalinfo-data-service';
import { HierarchyType, ParticipantType, ScoreCardLevel, CanAllView, SubjectArea, AnchorType } from '.././common/enums';
import { IReviewCreateInfoDataService, ReviewCreateDataService } from '../service/review-create-service';
import { ReviewCreateModel } from '../model/review-create-model';
import { GlobalInfoModel } from '../model/global-info-model';
import { MetricsDataModel, ScoreCardMetricMap } from '../model/metrics-data-model';
import * as angular from 'angular';
import _ from "lodash";
import { Subject } from 'rxjs/Subject';
import { ScoreCard } from '../model/scorecard-model';
import { Array } from 'es6-shim';
import { HasKey } from '../common/utilities';

export class ReviewEditController extends BaseContoller {

  public scoreCard: ScoreCard;
  public defaultTimeFrame: string;
  public canAllView: string;
  public participantType: string;
  public hierarchyType: string;
  public level: string;
  public minAmount: number;
  public maxAmount: number;
  public isEdit: boolean = true;
  public reviewcreateModel: ReviewCreateModel = new ReviewCreateModel();
  public subjectAreaMetrics: Array<any> = [];
  public selectedMetrics: Map<string, Array<ScoreCardMetricMap>>;
  public dateAnchor: string;
  public ownershipAnchor: string;
  public hierarchyAnchor: string;
  public isSendEmail: boolean;
  public emailFrequencyValue: boolean;
  public totalWeight: number = 0;

  constructor(private reviewcreateDataService: IReviewCreateInfoDataService, private $state: ng.ui.IStateService,
    private navigationStageService: INavigationStageService, private scorecardDataService: IScoreCardDataService,
    private commonEventsService: ICommonEventsService) {
    super();
    let scoreCardId = scorecardDataService.getCurrentScoreCardId();
    this.commonEventsService.getEvent('delete').takeUntil(this.$destroy).subscribe(() => {
      this.delete();
    });
    if (scoreCardId) {
      this.scorecardDataService.getScoreCard(scoreCardId).then(scoreCard => {
        if (<ScoreCard>scoreCard) {
          this.scoreCard = <ScoreCard>scoreCard;
          if (this.scoreCard.TimeFrames && this.scoreCard.TimeFrames.length > 0) {
            let timeFrame = this.scoreCard.TimeFrames.filter(x => x.Id === parseInt(this.scoreCard.DefaultTimeFrameId));
            this.defaultTimeFrame = timeFrame.length > 0 ? timeFrame[0]['Name'] : '';
          }

          this.participantType = ParticipantType[this.scoreCard.ParticipantType];
          this.hierarchyType = HierarchyType[this.scoreCard.HierarchyType];
          this.level = ScoreCardLevel[this.scoreCard.Level];
          this.canAllView = CanAllView[this.scoreCard.CanAllView === true ? 'All Participants' : CanAllView.Custom];
          this.reviewcreateModel.ScoreCard = scoreCard as ScoreCard;
          this.selectedMetrics = new Map();
          this.getSubjectAreas(this.scoreCard);
          this.isSendEmail = scoreCard['SendEmail'];
          this.emailFrequencyValue = scoreCard['EmailFrequencyValue'];
        }
      });
    }

  }

  public done() {
    this.$state.go('app');
  }

  public setStage(stage: string) {
    this.scorecardDataService.setIsEdit(this.scoreCard.Id);
    this.navigationStageService.setStage(Stage[stage], this.$state);
  }

  public delete() {
    this.reviewcreateDataService.deleteScoreCard(this.scoreCard.Id).then(data => {
      this.done();
    });
  }

  public getDataFilterValue(dfType: string): string {
    let filterType: any = '';
    debugger;
    if (this.reviewcreateModel.ScoreCard.DataFilters) {
      filterType = this.reviewcreateModel.ScoreCard.DataFilters.find(df => {
        return df.DataFilter.FilterName === dfType;
      });
    }
    if (dfType !== 'Estimate Amount') {
      return filterType.Values;
    } else {
      let amountArr = filterType.Values.split(',');
      this.minAmount = parseInt(amountArr[1]);
      this.maxAmount = parseInt(amountArr[2]);
      return amountArr[0];
    }
  }
  public getSubjectArea(subArea: number) {
    return SubjectArea[subArea];
  }
  public getSubjectAreas(scorecard: ScoreCard) {
    debugger;
    let subjectAreas: Array<string> = [];
    for (let metric of scorecard.Metrics) {
      let key = SubjectArea[metric.SubArea];
      if (subjectAreas.indexOf(key) == -1) {
        subjectAreas.push(key);
      }
    }
    for (let subArea in subjectAreas) {
      this.getSubjectAreaMetrics(subjectAreas[subArea]);
    }
  }
  public getSubjectAreaMetrics(subArea: string) {
    this.subjectAreaMetrics = [];
    let key = SubjectArea[subArea];
    let metricMaps = this.scoreCard.Metrics.filter(a => a.SubArea === key);
    if (metricMaps) {
      let mmarray = new Array<ScoreCardMetricMap>();
      if (HasKey(key, this.selectedMetrics)) {
        mmarray = this.selectedMetrics[subArea];
      }
      else {
        this.selectedMetrics[subArea] = mmarray;
      }
      for (let mm of <Array<any>>metricMaps) {
        this.totalWeight = this.totalWeight + mm.Weight;
        mmarray.push(mm);
      }
    }
  }
  public getAnchorName(subjectArea: string) {
    let key = SubjectArea[subjectArea];
    let metricObject = this.scoreCard.Metrics.find(d => d.SubArea === key);
    this.dateAnchor = metricObject.DateAnchor == undefined ? '' : metricObject.DateAnchor.Name;
    this.ownershipAnchor = metricObject.OwnershipAnchor == undefined ? '' : metricObject.OwnershipAnchor.Name;
    this.hierarchyAnchor = metricObject.HierarchyAnchor == undefined ? '' : metricObject.HierarchyAnchor.Name;
  }
  public getIsHeigherBetter(subjectArea: SubjectArea, metricId: number) {
    let metricObj = this.scoreCard.Metric.find(m => m.Id == metricId && m.SubjectArea == subjectArea)
    return metricObj.IsHeigherBetter;
  }
}

export const ReviewCreate: angular.IComponentOptions = {
  template: require('./review-edit.html'),
  controller: ReviewEditController
};


