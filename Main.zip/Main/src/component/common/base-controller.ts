import { Subject } from 'rxjs/Subject';

export class BaseContoller {
    private _$destroy: Subject<boolean>;

    /**
     *
     */
    constructor() {
        this._$destroy = new Subject<boolean>();
    }

    protected get $destroy(): Subject<boolean> {
        return this._$destroy;
    }

    $onDestroy() {
        this._$destroy.next(true);
    }

}