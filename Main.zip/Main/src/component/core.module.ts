import { from } from 'rxjs/observable/from';
import { CommonEventsService } from './service/common-events-service';
import { CommonService } from './service/common-service';
import { ReviewCreateDataService } from './service/review-create-service';
import { GlobalInfoDataService } from './service/globalinfo-data-service';
import { ModalDialog } from './service/modal-dialog-service';
import { MetricsDataService } from './service/metrics-data-service';
import { OtherConfigDataService } from './service/other-configurations-service';
import * as angular from 'angular';
import 'angular-material';
import 'angular-gettext';
import 'rxjs';

import { TopNavigation } from './top-navigation/top-navigation.component';
import { GlobalInfo } from './globalInfo/globalInfo.component';
import { Metrics } from './metrics/metrics.component';
import { Otherconfig } from './other-configurations/other-configurations.component';
import { ReviewCreate } from './review-edit/review-edit.component';
import { NavigationStageService } from './service/navigation-stage-service';
import { Scorecards } from './scorecards/scorecards.components';
import { CreateScoreCard } from './create-score-card/create-score-card.component';
import { ScoreCardView } from './scorecard-view/scorecard-view.component';
import { RegionView } from './scorecard-view/region-view.component';
import { ScoreCardDataService } from './service/scorecard-data-service';
import { ApiDataService } from './service/api-data-service';
import { Constants } from './common/constants';

import './po/en-ca.po';
import './po/en-us.po';
import './po/fr-ca.po';

export default angular
    .module('mi.reporting.scorecard.configuration', ['ngMaterial', 'gettext'])
    .component('createScoreCard', CreateScoreCard)
    .component('topNavigation', TopNavigation)
    .component('global', GlobalInfo)
    .component('metrics', Metrics)
    .component('otherconfig', Otherconfig)
    .component('reviewcreate', ReviewCreate)
    .component('scorecards', Scorecards)
    .component('scorecardview', ScoreCardView)
    .component('regionview', RegionView)
    .constant('constants', new Constants())
    .service('commonEventsService', CommonEventsService)
    .service('commonService', CommonService)
    .service('navigationStageService', NavigationStageService)
    .service('scorecardDataService', ScoreCardDataService)
    .service('modalDialog', ModalDialog)
    .service('globalInfoDataService', GlobalInfoDataService)
    .service('reviewcreateDataService', ReviewCreateDataService)
    .service('metricsDataService', MetricsDataService)
    .service('otherConfigDataService', OtherConfigDataService)
    .service('apiDataService', ApiDataService)
    .name;
