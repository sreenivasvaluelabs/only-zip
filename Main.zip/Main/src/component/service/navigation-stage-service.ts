
export enum Stage {
    GlobalInfo,
    Metrics,
    OtherConfiguration,
    ReviewAndEdit
}

export interface INavigationStageService {
    getStage(): Stage;
    setStage(stage: Stage, state: ng.ui.IStateService);
    isCurrentStage(name: string): boolean;

}

export class NavigationStageService implements INavigationStageService {

    private currentStage: Stage;
    public getStage(): Stage {
        return this.currentStage;
    }

    public setStage(stage: Stage, state: ng.ui.IStateService) {
        this.currentStage = stage;
        if (state) {
            state.go('create-score-card', { stage: this.currentStage.toString() });
        }
    }

    public isCurrentStage(name: string): boolean {
        if (Stage[this.currentStage] === name) {
            return true;
        } else {
            return false;
        }
    }
}