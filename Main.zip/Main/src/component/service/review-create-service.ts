import { Constants, IConstants } from '../common/Constants';
import { IApiDataService, ApiDataService } from '../service/api-data-service';

export interface IReviewCreateInfoDataService {
    deleteScoreCard(scoreCardId: number): ng.IPromise<any>;
}

export class ReviewCreateDataService implements IReviewCreateInfoDataService {

    constructor(private apiDataService: IApiDataService, private constants: IConstants) {

    }

    public deleteScoreCard(scoreCardId: number): ng.IPromise<any> {
        return this.apiDataService
            .delete(this.constants.BaseUrl + 'scoreCards/' + scoreCardId)
            .then(data => {
                return data;
            }).catch(error => {
                console.log(error);
            });
    }
}