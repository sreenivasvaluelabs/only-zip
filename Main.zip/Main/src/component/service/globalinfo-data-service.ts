import { Participant } from '../model/participant-model';
import { TimeFrame } from '../model/time-frame-model';
import { ScoreCardDataService, IScoreCardDataService } from './scorecard-data-service';
import * as constants from 'constants';
import { arrayify } from 'tslint/lib/utils';
import { GlobalInfoModel, Region, Division, Office, Resource } from '../model/global-info-model';
import { HierarchyType, ParticipantType, ScoreCardLevel } from '.././common/enums';
import { IApiDataService, ApiDataService } from './api-data-service';
import { Constants, IConstants } from '../common/Constants';
import { ICommonService, CommonService } from './common-service';
import { ScoreCard } from '../model/scorecard-model';


export interface IGlobalInfoDataService {
    getParticipants();
    getTimeFrames(): ng.IPromise<void | Map<number, Array<TimeFrame>>>;
    getTimeFrameList(): Array<TimeFrame>;
    getAllRegions(): ng.IPromise<void | Array<Region>>;
    getDivisionsByRegionId(regionId: number): ng.IPromise<void | Array<Division>>;
    getOfficesByDivisionId(divisionId: number): ng.IPromise<void | Array<Office>>;
    getResourcesByOfficeId(officeId: number, participantType?: ParticipantType): ng.IPromise<void | Array<Resource>>;
    save(model: ScoreCard): ng.IPromise<void | number>;
    checkScoreCardName(scoreCardId: number, scoreCardName: string): ng.IPromise<any>;
    getCustomGroupResources(scoreCardId: number): ng.IPromise<void | Array<Resource>>;
    getPreSavedScoreCard(): ScoreCard;
}

export class GlobalInfoDataService implements IGlobalInfoDataService {
    private scoreCardLevelList: Array<any>;
    private participantsList: Array<any>;
    private timeFrameGroups: Map<number, Array<TimeFrame>>;
    private timeFrames: Array<TimeFrame>;
    private whoCanViewList: Array<Participant>;
    private stdheirarcyList: Array<Participant>;
    private preSavedScoreCard: ScoreCard;

    constructor(private apiDataService: IApiDataService, private constants: IConstants,
        private scorecardDataService: IScoreCardDataService,
        private commonService: ICommonService, private $q: ng.IQService) {
        this.timeFrameGroups = new Map();
        this.timeFrames = new Array();

        this.participantsList = [
            { Key: ParticipantType.NetworkShops, Name: 'Network Shop(s)' },
            { Key: ParticipantType.OutOfNetWorkShops, Name: 'Out of Network Shop(s)' },
            { Key: ParticipantType.Staff, Name: 'Staff' },
            { Key: ParticipantType.IA, Name: 'IA' }
        ];
    }

    public getParticipants() {
        return this.participantsList;
    };

    public getTimeFrames(): ng.IPromise<void | Map<number, Array<TimeFrame>>> {
        return this.apiDataService
            .getData(this.constants.BaseUrl + 'timeframes')
            .then(timeFrameList => {
                let tfGroupList = <Array<Array<any>>>timeFrameList;
                if (tfGroupList) {
                    for (let i = 0; i < tfGroupList.length; i++) {
                        let tfGroup = tfGroupList[i];
                        if (tfGroup && tfGroup.length > 0) {
                            let tfl = new Array<TimeFrame>();
                            for (let tf of tfGroup) {
                                tfl.push({
                                    Id: tf['Id'],
                                    Name: tf['Name'],
                                    Description: tf['Description'],
                                    isChecked: false
                                });
                            }
                            this.timeFrameGroups.set(i, tfl);
                            this.timeFrames = this.timeFrames.concat(tfl);
                        }
                    }
                    return this.timeFrameGroups;
                }
                return null;
            }).catch(error => {
                console.log(error);
            });
    }

    public getTimeFrameList(): Array<TimeFrame> {
        return this.timeFrames;
    }

    public checkScoreCardName(scoreCardId: number, scoreCardName: string): ng.IPromise<any> {
        return this.apiDataService
            .getData(this.constants.BaseUrl + 'ScoreCards/CheckScoreCardName/' + (scoreCardId > 0 ? scoreCardId : -1) + '/' + scoreCardName)
            .then(data => {
                return data;
            }).catch(error => {
                console.log(error);
            });
    }

    public getAllRegions(): ng.IPromise<void | Array<Region>> {
        return this.apiDataService
            .getData(this.constants.BaseUrl + 'hierarchy/regions')
            .then(data => {
                if (data) {
                    let regions = new Array<Region>();
                    for (let reg of <Array<any>>data) {
                        regions.push({
                            Key: reg['Key'],
                            Name: reg['Name'],
                            Code: reg['Code'],
                            Level: reg['Level'],
                            Status: false
                        });
                    }
                    return regions;
                }
                return null;
            }).catch(error => {
                console.log(error);
            });
    }

    public getDivisionsByRegionId(regionId: number): ng.IPromise<void | Array<Division>> {
        return this.apiDataService
            .getData(this.constants.BaseUrl + 'hierarchy/divisions/' + regionId)
            .then(data => {
                if (data) {
                    let divisions = new Array<Division>();
                    for (let div of <Array<any>>data) {
                        divisions.push({
                            Key: div['Key'],
                            Name: div['Name'],
                            Code: div['Code'],
                            Level: div['Level'],
                            Status: false
                        });
                    }
                    return divisions;
                }
                return null;
            }).catch(error => {
                console.log(error);
            });
    }

    public getOfficesByDivisionId(divisionId: number): ng.IPromise<void | Array<Office>> {
        return this.apiDataService
            .getData(this.constants.BaseUrl + 'hierarchy/offices/' + divisionId)
            .then(data => {
                if (data) {
                    let offices = new Array<Office>();
                    for (let office of <Array<any>>data) {
                        offices.push({
                            Key: office['Key'],
                            Name: office['Name'],
                            Code: office['Code'],
                            Level: office['Level'],
                            Status: false
                        });
                    }
                    return offices;
                }
                return null;
            }).catch(error => {
                console.log(error);
            });
    }

    public getResourcesByOfficeId(officeId: number, participantType: ParticipantType): ng.IPromise<void | Array<Resource>> {
        return this.apiDataService
            .getData(this.constants.BaseUrl + 'hierarchy/resources/' + officeId + '/' + (participantType >= 0 ? participantType : ''))
            .then(data => {
                if (data) {
                    let resources = new Array<Resource>();
                    for (let res of <Array<any>>data) {
                        resources.push({
                            Key: res['Key'],
                            Name: res['Name'],
                            IsExists: false,
                            Code: res['Code'],
                            Level: res['Level'],
                            Status: false
                        });
                    }
                    return resources;
                }
                return null;
            }).catch(error => {
                console.log(error);
            });
    }

    public getCustomGroupResources(scoreCardId: number): ng.IPromise<void | Array<Resource>> {
        return this.apiDataService
            .getData(this.constants.BaseUrl + 'hierarchy/custom/' + scoreCardId)
            .then(data => {
                if (data) {
                    let resources = new Array<Resource>();
                    for (let reg of <Array<any>>data) {
                        resources.push({
                            Key: reg['Key'],
                            Code: reg['Code'],
                            Name: reg['Name'],
                            IsExists: true
                        });
                    }
                    return resources;
                }
                return null;
            }).catch(error => {
                console.log(error);
            });
    }

    public save(model: ScoreCard): ng.IPromise<void | number> {
        return this.apiDataService
            .postData(this.constants.BaseUrl + 'globalinfo', model)
            .then((data) => {
                let id = parseInt(data.toString(), 10);
                this.scorecardDataService.setCurrentScoreCardId(id);
                this.preSavedScoreCard = model;
                return id;
            })
            .catch((error) => console.log(error));
    }

    public getPreSavedScoreCard(): ScoreCard {
        return this.preSavedScoreCard;
    }
}