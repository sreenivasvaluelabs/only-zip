import { DataFilterMap } from './data-filter-map-model';
export class DataFiilterVM {
    DataFiltersMappedList: Array<DataFilterMap>;
    IsSendEmail: boolean;
}
