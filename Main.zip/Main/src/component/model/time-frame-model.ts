export class TimeFrame {
    public Id: number;
    public Name: string;
    public Description: string;
    public StartDate?: Date;
    public EndDate?: Date;
    public Order?: number;
    public isChecked?: boolean;
}
