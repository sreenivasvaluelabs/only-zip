export class SetupConfigModel {
    ScoreCardName: string;
    Description: string;
}

