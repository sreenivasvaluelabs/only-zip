import { DataFilter } from './data-filter-model';

export class OtherConfigModel {
    public scoreCardId: number;
    public copiedScoreCardId: string;
    public regionList: Array<any> = [];
    public dataFilterList: Array<any> = [];
    public dataFilterStatusList: Array<any> = [];
    public DRNList: Array<any>;
    public availableTimeFrameList: Array<any> = [];
    public primaryTimeFrameList: Array<any>;
    public customizeStdParticipantsList: Array<any> = [];
    public customizeStdParticipantsList1: Array<any> = [];
    public participantsList: Array<any> = [];
    public customHierarcyList: Array<any> = [];
    public divisionList: Array<any> = [];
    public officeList: Array<any> = [];
    public resourceList: Array<any> = [];
    public selectedFilterToRemove = [];
    public scorecardName: string;
    public scorecardDescription: string;
    public selectedTimeFrames: Array<any> = [];
    public selectedParticipants: Array<any> = [];
    public selectedDataFilters: Array<ScoreCardDataFilterMapModel> =[];
}

export class ScoreCardDataFilterMapModel {
    public Values: string;
    public ScoreCardId: string;
    public DataFilterId: string;
}


