import { ScoreCardLevel } from '../common/enums';

export class Participant {
    public Key: number;
    public Code: string;
    public Name: string;
    public Children?: Array<Participant>;
    public Status?: boolean;
    public Level?: ScoreCardLevel;
    public ReferenceKey?: number;
}

// export class Division {
//     Id: string;
//     public Name: string;
//     Offices: Array<Office>;
//     public Status: boolean;
// }

// export class Office {
//     Id: string;
//     public Name: string;
//     Shops: Array<Shop>;
//     public Status: boolean;
// }

// export class Shop {
//     Id: string;
//     Name: string;
//     public Status: boolean;
// }
