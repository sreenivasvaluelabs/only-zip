import { ScoreCard } from "./scorecard-model";

//import { CanAllView } from '.././common/enums';
export class ReviewCreateModel {
    public ScoreCard: ScoreCard;

}