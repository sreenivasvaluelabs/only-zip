import { BaseContoller } from '../common/base-controller';
import { ICommonEventsService, CommonEventsService } from '../service/common-events-service';
import _ from "lodash";
import { IMetricsDataService, MetricsDataService } from '../service/metrics-data-service';
import { MetricsDataModel, Metric, ScoreCardMetricMap, Anchor } from '../model/metrics-data-model';
import { Subject } from 'rxjs/Subject';
import { IScoreCardDataService } from "../service/scorecard-data-service";
import { Array, Map } from 'es6-shim';
import { SubjectArea, AnchorType } from '../common/enums';
import { HasKey } from '../common/utilities';
import { isNullOrUndefined } from "util";


export class MetricsController extends BaseContoller {

    public metricsList: Array<Metric>;
    public metrics: Map<string, Array<Metric>>;
    public selectedMetrics: Map<string, Array<ScoreCardMetricMap>>;
    public anchors: Array<Anchor>;
    public subjectAreaAnchors: Array<Anchor>;
    public isKpiSelected: boolean;
    public modalAnchors: boolean;
    public currentSubjectArea: number;
    public selectedDateAnchor: number;
    public selectedOwnershipAnchor: number;
    public selectedHierarchyAnchor: number;
    public isRequired: boolean = false;
    public totalWeight: number;
    public selMetric: number;


    constructor(private metricsDataService: MetricsDataService, private commonEventsService: ICommonEventsService, private scorecardDataService: IScoreCardDataService, private $state: ng.ui.IStateService) {
        super();
        debugger;
        this.selectedMetrics = new Map();
        this.commonEventsService.getEvent('save').takeUntil(this.$destroy).subscribe(() => {
            this.save();
        });

        this.metricsDataService.getAllMetrics().then(val => {
            if (<Array<Metric>>val) {

                this.metricsList = <Array<Metric>>val;
                this.metrics = new Map<string, Array<Metric>>();
                for (let m of this.metricsList) {
                    var key = SubjectArea[m.SubjectArea];
                    let marray = new Array<Metric>();
                    if (HasKey(key, this.metrics)) {
                        marray = this.metrics[key]
                    } else {
                        this.metrics[key] = marray;
                    }
                    marray.push(m);
                }
                let currentScoreCard = this.scorecardDataService.getCurrentScoreCard();
                if (currentScoreCard && currentScoreCard.Metrics) {

                    for (let mm of currentScoreCard.Metrics) {
                        let m = this.metricsList.find(m => m.Id === mm.MetricId);
                        if (m) {
                            let key = SubjectArea[m.SubjectArea];
                            let mmarray = new Array<ScoreCardMetricMap>();
                            if (HasKey(key, this.selectedMetrics)) {
                                mmarray = this.selectedMetrics[key];
                            } else {
                                this.selectedMetrics[key] = mmarray;
                            }
                            mmarray.push(mm);
                        }
                    }
                    this.isKpiSelected = true;
                    this.calculateTotalWeight();
                }
            }
        });
        this.metricsDataService.getAllAnchors().then(val => {
            if (<Array<Anchor>>val) {
                this.anchors = <Array<Anchor>>val;
            }
        });
    }

    public selectMetric(subjectArea: string, metric: Metric) {
        this.isKpiSelected = true;
        let mmarray = new Array<ScoreCardMetricMap>();
        if (HasKey(subjectArea, this.selectedMetrics)) {
            mmarray = this.selectedMetrics[subjectArea];
        } else {
            this.selectedMetrics[subjectArea] = mmarray;
        }
        let mmIndex = mmarray.findIndex(m => m.MetricId === metric.Id);
        if (mmIndex > -1) {
            mmarray.splice(mmIndex, 1);
        } else {
            let key = SubjectArea[subjectArea];
            this.selectedDateAnchor = this.getDefaultAnchor(key, AnchorType.Date)
            this.selectedOwnershipAnchor = this.getDefaultAnchor(key, AnchorType.Ownership);
            this.selectedHierarchyAnchor = this.getDefaultAnchor(key, AnchorType.Hierarchy);
            mmarray.push({
                MetricId: metric.Id,
                MetricName: metric.Name,
                ScoreThisMetric: true,
                SubArea: metric.SubjectArea,
                DateAnchorId: this.selectedDateAnchor,
                OwnershipAnchorId: this.selectedOwnershipAnchor,
                HierarchyAnchorId: this.selectedHierarchyAnchor,
                DateAnchor: null,
                OwnershipAnchor: null,
                HierarchyAnchor: null
            });
            this.selMetric = metric.Id;
        }
        this.calculateTotalWeight();
    }

    public isMetricSelected(subjectArea: string, metric: Metric) {
        if (HasKey(subjectArea, this.selectedMetrics)) {
            let mmarray = <Array<ScoreCardMetricMap>>this.selectedMetrics[subjectArea];
            if (mmarray) {
                let mm = mmarray.find(m => m.MetricId === metric.Id);
                if (mm) {
                    return true;
                }
            }
        }
        return false;
    }

    public getSubjectArea(subjectArea: string) {
        return SubjectArea[subjectArea];
    }

    public getIsHeigherBetter(subjectArea: SubjectArea, metricId: string) {
        let metricObj = this.metrics[SubjectArea[subjectArea]].find(m => m.Id == metricId)
        return metricObj.IsHeigherBetter;
    }

    public getSubjectAreaAnchors(subArea: SubjectArea) {
        this.subjectAreaAnchors = this.anchors.filter(a => a.SubjectArea === subArea);
        this.currentSubjectArea = subArea;
        this.selectedDateAnchor = null;
        this.selectedOwnershipAnchor = null;
        this.selectedHierarchyAnchor = null;
        let mmarray = new Array<ScoreCardMetricMap>();
        let key = SubjectArea[subArea];
        mmarray = this.selectedMetrics[key];
        if (mmarray) {
            this.selectedDateAnchor = mmarray[0].DateAnchorId;
            this.selectedOwnershipAnchor = mmarray[0].OwnershipAnchorId;
            this.selectedHierarchyAnchor = mmarray[0].HierarchyAnchorId;
        }
        this.modalAnchors = true;
    }

    public getDefaultAnchor(subjectArea: SubjectArea, anchorType: AnchorType): number {
        let defaultAnchor = this.anchors.find(a => a.SubjectArea == subjectArea && a.Default === true && a.Type === anchorType);
        return defaultAnchor ? defaultAnchor.Id : null;
    }

    public closeDialog() {
        this.modalAnchors = false;
    }

    public saveSubjectAreaAnchorData(subArea: SubjectArea) {
        let key = SubjectArea[subArea];
        let mmarray = new Array<ScoreCardMetricMap>();
        mmarray = this.selectedMetrics[key];
        mmarray.forEach((val) => {
            val.DateAnchorId = this.selectedDateAnchor;
            val.OwnershipAnchorId = this.selectedOwnershipAnchor;
            val.HierarchyAnchorId = this.selectedHierarchyAnchor;
        });
        this.modalAnchors = false;
    }

    public calculateTotalWeight() {
        this.totalWeight = 0;
        for (let obj in this.selectedMetrics) {
            let mmarray = this.selectedMetrics[obj];
            mmarray.forEach((val) => {
                if (val.Weight != undefined) {
                    this.totalWeight = this.totalWeight + parseInt(val.Weight);
                }
            });
        }
    }

    public clearWeight(selectedmetric: ScoreCardMetricMap) {
        selectedmetric.Weight = null;
        this.calculateTotalWeight();
    }

    public getMaxLength(event: any, selectedmetric: string, len: number) {
        debugger;
        if (selectedmetric && selectedmetric.length > len) {
            event.preventDefault();
        }
    }
    public validateData(selectedmetric: any, key: string) {
        debugger;
        var reg = new RegExp(/^[0-9]*$/);
        var val = selectedmetric[key];
        if (val) {
            var ret = reg.test(val);
            if (!ret) {
                selectedmetric[key] = parseInt(selectedmetric[key].toString().substr(0, selectedmetric[key].toString().length - 1));
            }
        }
    }

    private save() {
        debugger;
        let selectedMetricMaps = new Array<ScoreCardMetricMap>();
        this.isRequired = false;
        for (let key in this.selectedMetrics) {
            let subAreametrics = this.selectedMetrics[key];
            subAreametrics.forEach(element => {
                if (element.Target == undefined) {
                    this.isRequired = true;
                }
            });
            selectedMetricMaps = selectedMetricMaps.concat(this.selectedMetrics[key]);
        }
        if (!this.isRequired) {
            this.metricsDataService.save(selectedMetricMaps).then(data => {
                if (data) {
                    this.commonEventsService.getEvent('next').next();
                    this.isRequired = false;
                }
            });
        }
    }
}

export const Metrics: angular.IComponentOptions = {
    template: require('./metrics.html'),
    controller: MetricsController
};






