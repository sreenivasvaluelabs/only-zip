
export class RegionViewInfoController {


}

export const RegionView: angular.IComponentOptions = {
    template: require('./region-view.html'),
    controller: RegionViewInfoController
};
