import * as angular from 'angular';
import 'angular-material';
import 'angular-mocks';
import 'jasmine';

import './../core.module';
import { CreateScoreCardController } from './create-score-card.component';

describe('createScoreCard component', () => {
    beforeEach(() => {
        angular.mock.module('ngMaterial');
        angular.mock.module('mi.reporting.scorecard.configuration');
    });

    it('should load globalinfo by default', angular.mock.inject(($rootScope: ng.IRootScopeService
        , $compile: ng.ICompileService
        , $componentController: ng.IComponentControllerService
    ) => {
        const component = $componentController('createScoreCard', { '$state': null }, {}) as CreateScoreCardController;
        const isGlobalInfo = component.isCurrentPage('GlobalInfo');
        expect(isGlobalInfo).toEqual(true);
    }));
});
