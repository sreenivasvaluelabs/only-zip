import { Hierarchy } from '../model/global-info-model';
import { IGlobalInfoDataService } from '../service/globalinfo-data-service';
import { EmailSubscription } from '../model/email-subscription.model';
import { EmailFrequency } from '../common/enums';
import { Participant } from '../model/participant-model';
import { ScoreCardDataService, IScoreCardDataService } from '../service/scorecard-data-service';
import { ICommonEventsService, CommonEventsService } from '../service/common-events-service';
import { BaseContoller } from '../common/base-controller';
import { IOtherConfigDataService, OtherConfigDataService } from '../service/other-configurations-service';
import { OtherConfigModel } from '../model/other-configurations-model';
import { DataFilterMap } from '../model/data-filter-map-model';
import { DataFilter } from '../model/data-filter-model';
import { Array } from 'es6-shim';
import { isNullOrUndefined } from 'util';
import { DataFiilterVM } from '../model/data-filter-view-model';
import * as angular from 'angular';
import { ScoreCard } from '../model/scorecard-model';

export class OtherConfigurationsController extends BaseContoller {

    public otherConfigModel: OtherConfigModel = new OtherConfigModel();
    public showMinMax: boolean = false;
    public showLessOrMore: boolean = false;
    public minimumAmount: number = null;
    public maximumAmount: number = null;
    public otherAmount: number = null;
    public modalCustomizeScorecardviewers: boolean = false;
    public modalCustomHierarcy: boolean = false;
    public selectedVehicles: string = 'Any';
    public selectedDrivability: string;
    public selectedRepairability: string;
    public selectedEstimatingSystem: string;
    public selectedEstimateAmount: string;
    public expanded = false;
    public isClear: boolean;
    public selectedDataFilters: Array<DataFilterMap>;
    public allDataFilters: Array<DataFilter>;
    public vehicleTypeList: Array<any> = [];
    public drivabilityTypeList: Array<any> = [];
    public repairabilityTypeList: Array<any> = [];
    public estimatingSystemTypeList: Array<any> = [];
    public estimatingAmountTypeList: Array<any> = [];
    public participantsList: Array<Participant>;
    public selectedParticipantsList: Array<Participant>;
    public whoCanViewParticipants: Array<Participant>;
    public copyOfWhoCanViewParticipants: Array<Participant>;
    public emailFrequency = EmailFrequency;
    public checkedEmailPreferences: boolean = false;
    public selectedPrimaryTimeFrame: string = null;
    public selectedRegion: Participant;
    public emailSubscriptionList: Array<EmailSubscription>;
    public isEditDataFilter: boolean = false;
    public dataFilterViewModel: DataFiilterVM;
    public isNotEmailFrequency: boolean = false;
    public selectedHierarchy: Array<Hierarchy>;
    public tempScoreCard: ScoreCard;
    public participantLevel: number;
    // public selectedHierarchyList: any = [];

    constructor(private otherConfigDataService: IOtherConfigDataService
        , private commonEventsService: ICommonEventsService
        , private globalInfoDataService: IGlobalInfoDataService
        , private scorecardDataService: IScoreCardDataService) {

        super();
        let scoreCard: ScoreCard = this.scorecardDataService.getCurrentScoreCard();
        this.tempScoreCard = this.globalInfoDataService.getPreSavedScoreCard();
        if (!isNullOrUndefined(scoreCard)) {
            this.selectedHierarchy = scoreCard.ScoreCardVisibilityMaps;
            this.participantLevel = scoreCard.Level;
            this.checkedEmailPreferences = scoreCard.SendEmail;
        } else if (!isNullOrUndefined(this.tempScoreCard)) {
            this.selectedHierarchy = this.tempScoreCard.ScoreCardVisibilityMaps;
            this.participantLevel = this.tempScoreCard.Level;
            this.checkedEmailPreferences = false;
        }

        this.otherConfigModel.scoreCardId = this.scorecardDataService.getCurrentScoreCardId();

        this.modalCustomHierarcy = false;

        this.otherConfigDataService.getAllDataFilters().then((data) => {
            if (data) {
                this.allDataFilters = data;
                this.vehicleTypeList = this.getPossibleValues('Vehicle Type');
                this.drivabilityTypeList = this.getPossibleValues('Drivability');
                this.repairabilityTypeList = this.getPossibleValues('Repairability');
                this.estimatingSystemTypeList = this.getPossibleValues('Estimating System');
                this.estimatingAmountTypeList = this.getPossibleValues('Estimate Amount');
                this.setEmptySelectedDataFilters();
            }
        });

        if (this.otherConfigModel.scoreCardId) {
            this.otherConfigDataService.getParticipantsData(this.otherConfigModel.scoreCardId).then((data) => {
                if (!isNullOrUndefined(data)) {
                    this.participantsList = new Array<Participant>();
                    for (let reg of <Array<any>>data) {
                        this.participantsList.push({
                            Key: reg['Participant'].Key,
                            Code: reg['Participant'].Code,
                            Level: reg['Participant'].Level,
                            Name: reg['Participant'].Name,
                            Status: false,
                            Children: reg['Participant'].Children,
                            ReferenceKey: reg['Participant'].ReferenceKey
                        });
                    }
                    if (data[0] && data[0]['Schedules']) {
                        this.selectedPrimaryTimeFrame = this.emailFrequency[data[0]['Schedules'][0]];
                    }
                }
            });

            this.globalInfoDataService.getAllRegions().then((data) => {
                if (data) {
                    this.whoCanViewParticipants = data as Array<Participant>;
                    if (this.selectedHierarchy) {
                        this.setCustomHierarchy(this.whoCanViewParticipants, 'RegionKey');
                    }

                    if (this.otherConfigModel.scoreCardId) {
                        this.otherConfigDataService.getScoreCardDataFilterData(this.otherConfigModel.scoreCardId).then(scoreCardDFData => {
                            if (scoreCardDFData && scoreCardDFData.length > 0) {
                                this.setTargetData(scoreCardDFData);
                                this.isEditDataFilter = true;
                            } else {
                                this.isEditDataFilter = false;
                            }
                        });
                    } else {
                        this.isEditDataFilter = false;
                    };
                }
            });
        }

        this.commonEventsService.getEvent('save').takeUntil(this.$destroy).subscribe(() => {
            this.save();
        });

        this.selectedDataFilters = new Array<DataFilterMap>();
        this.selectedParticipantsList = new Array<Participant>();
    };

    public setCustomHierarchy(participantsList: Array<Participant>, filterKey: string) {
        this.selectedHierarchy.forEach(obj => {
            if (!isNullOrUndefined(obj[filterKey])) {
                let pickedParticipant = participantsList.find(reg => {
                    return reg.Key === obj[filterKey];
                });
                if (!isNullOrUndefined(pickedParticipant)) {
                    pickedParticipant.Status = true;
                }
            }
        });
    }

    public setCustomHierarchyData(selectedPrticipant: Participant, filterKey: string) {
        if (selectedPrticipant.Status === true) {
            selectedPrticipant.Children.map(obj => {
                obj.Status = true;
            });
        } else {
            this.setCustomHierarchy(selectedPrticipant.Children, filterKey);
        }
    }

    public setTargetData(scoreCardDFData: any) {
        let selectedVehicle: DataFilterMap = scoreCardDFData.find(obj => {
            return obj.DataFilter.FilterName === 'Vehicle Type';
        });
        this.selectedVehicles = selectedVehicle.Values.toLocaleString();
        let selectedVehiclesList = new DataFilterMap();
        selectedVehiclesList.DataFilterId = selectedVehicle.DataFilter.Id;
        selectedVehiclesList.Values = selectedVehicle.Values;
        this.selectedDataFilters = new Array<DataFilterMap>();
        this.selectedDataFilters.push(selectedVehiclesList);

        let drivability: DataFilterMap = scoreCardDFData.find(obj => {
            return obj.DataFilter.FilterName === 'Drivability';
        });
        this.selectedDrivability = drivability.Values[0];

        let repairability: DataFilterMap = scoreCardDFData.find(obj => {
            return obj.DataFilter.FilterName === 'Repairability';
        });
        this.selectedRepairability = repairability.Values[0];

        let estimatingSystem: DataFilterMap = scoreCardDFData.find(obj => {
            return obj.DataFilter.FilterName === 'Estimating System';
        });
        this.selectedEstimatingSystem = estimatingSystem.Values[0];

        let estimateAmount: DataFilterMap = scoreCardDFData.find(obj => {
            return obj.DataFilter.FilterName === 'Estimate Amount';
        });
        this.selectedEstimateAmount = estimateAmount.Values[0];
        if (estimateAmount.Values[0] === 'Between') {
            this.showMinMax = true;
            this.minimumAmount = parseInt(estimateAmount.Values[1]);
            this.maximumAmount = parseInt(estimateAmount.Values[2]);
        } else if (estimateAmount.Values[0] === 'Only Less Than' || estimateAmount.Values[0] === 'Only More Than') {
            this.showLessOrMore = true;
            this.otherAmount = parseInt(estimateAmount.Values[1]);
        }

        if (!isNullOrUndefined(this.participantsList) && !isNullOrUndefined(this.whoCanViewParticipants)) {
            this.participantsList.forEach(obj => {
                this.setSelectedParticipant(obj, this.whoCanViewParticipants);
            });
            this.copyOfWhoCanViewParticipants = angular.copy(this.whoCanViewParticipants);
        }
    }

    public getParticipantsByRefKey(selectedParticipant: Participant) {
        if (isNullOrUndefined(selectedParticipant.Children)) {
            switch (selectedParticipant.Level) {
                case 1:
                    this.globalInfoDataService.getDivisionsByRegionId(selectedParticipant.Key).then(childs => {
                        if (!isNullOrUndefined(childs)) {
                            selectedParticipant.Children = childs as Array<Participant>;
                            this.setCustomHierarchyData(selectedParticipant, 'DivisionKey');
                        }
                    });
                    break;
                case 2:
                    this.globalInfoDataService.getOfficesByDivisionId(selectedParticipant.Key).then(childs => {
                        if (!isNullOrUndefined(childs)) {
                            selectedParticipant.Children = childs as Array<Participant>;
                            this.setCustomHierarchyData(selectedParticipant, 'OfficeKey');
                        }
                    });
                    break;
                case 3:
                    this.globalInfoDataService.getResourcesByOfficeId(selectedParticipant.Key).then(childs => {
                        if (!isNullOrUndefined(childs)) {
                            selectedParticipant.Children = childs as Array<Participant>;
                            this.setCustomHierarchyData(selectedParticipant, 'ParticipantKey');
                        }
                    });
                    break;
            }
        }
    }

    public setSelectedParticipant(participant: Participant, participants: Array<Participant>) {
        let existedParticipant = participants.find(obj => {
            return obj.Key === participant.Key;
        });
        if (!isNullOrUndefined(existedParticipant)) {
            this.selectedParticipantsList.push(existedParticipant);
            this.selectParticipantLevel(existedParticipant);
            return;
        } else {
            participants.forEach(obj => {
                if (obj.Level < 4 && !isNullOrUndefined(obj.Children)) {
                    this.setSelectedParticipant(participant, obj.Children);
                }
            });
        }
    }

    public selectParticipantLevel(participant: Participant) {
        participant.Status = true;
        if (participant.Level < 4 && participant.Children) {
            participant.Children.forEach(obj => {
                this.selectParticipantLevel(obj);
            });
        }
    }

    public getPossibleValues(typeName: string): Array<any> {
        if (!this.allDataFilters) {
            return [];
        }
        let valuesList: DataFilter = this.allDataFilters.find(obj => obj.FilterName === typeName);
        let possibleValues = [];
        let idVal = 0;
        for (let val of valuesList.PossibleValues) {
            possibleValues.push(val);
        }
        return possibleValues;
    }

    public setEmptySelectedDataFilters() {
        this.selectedDataFilters = new Array<DataFilterMap>();
        let valuesList: DataFilter = this.allDataFilters.find(obj => obj.FilterName === 'Vehicle Type');
        let vehicleDataFiilter = new DataFilterMap();
        vehicleDataFiilter.DataFilterId = valuesList.Id;
        vehicleDataFiilter.Values = ['Any'];
        this.selectedDataFilters.push(vehicleDataFiilter);
    }

    public showCheckboxes() {
        var checkboxes = document.getElementById('multiCheckboxes');
        if (!this.expanded) {
            checkboxes.style.display = 'block';
            this.expanded = true;
        } else {
            // var checkboxes = document.getElementById("multiCheckboxes");
            checkboxes.style.display = 'none';
            this.expanded = false;
        }
    }

    public onClearCheckboxes() {
        this.setEmptySelectedDataFilters();
        this.isClear = false;
    }

    public getCheckedStatus(val: string): boolean {
        let df = this.allDataFilters.filter(obj => obj.FilterName === 'Vehicle Type')[0];
        let dfm = this.selectedDataFilters.filter(obj => obj.DataFilterId === df.Id);
        if (dfm && dfm.length > 0) {
            let selectedMap = dfm[0];
            if (selectedMap.Values) {
                let slVal = selectedMap.Values.findIndex(v => v === val);
                if (slVal > -1) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public selectDataFilter(val: string) {
        let df = this.allDataFilters.filter(obj => obj.FilterName === 'Vehicle Type')[0];
        let dfm = this.selectedDataFilters.filter(obj => obj.DataFilterId === df.Id);
        console.log(dfm[0]);
        if (dfm && dfm.length > 0) {
            let selectedMap = dfm[0];
            if (selectedMap.Values) {
                let slVal = selectedMap.Values.findIndex(v => v === val);
                if (slVal > -1) {
                    selectedMap.Values.splice(slVal, 1);
                } else {
                    selectedMap.Values.push(val);
                }
            } else {
                selectedMap.Values = [val];
            }
        } else {
            let ndfm = new DataFilterMap();
            ndfm.DataFilterId = df.Id;
            ndfm.Values = [val];
            this.selectedDataFilters.push(ndfm);
        }

        if (this.isClear === false) {
            this.isClear = true;
        }
    }

    public onApply() {
        if (this.selectedDataFilters.length > 0) {
            let labelsArr: Array<any> = [];
            if (this.selectedDataFilters[0].Values.length > 0) {
                if (this.selectedDataFilters[0].Values.length > 1) {
                    let anyIndex: number = this.selectedDataFilters[0].Values.indexOf('Any');
                    if (anyIndex >= 0) {
                        this.selectedDataFilters[0].Values.splice(anyIndex, 1);
                    }
                }
                this.selectedVehicles = this.selectedDataFilters[0].Values.toLocaleString();
            }
        } else {
            this.selectedVehicles = 'Any';
        }
        var checkboxes = document.getElementById('multiCheckboxes');
        checkboxes.style.display = 'none';
        this.expanded = false;
    }

    public updateAmount(selectedAmount: string) {
        if (selectedAmount) {
            if (selectedAmount === 'Between') {
                this.showMinMax = true;
                this.showLessOrMore = false;
            } else if (selectedAmount === 'Only Less Than' || selectedAmount === 'Only More Than') {
                this.showMinMax = false;
                this.showLessOrMore = true;
            }
        } else {
            this.showMinMax = false;
            this.showLessOrMore = false;
        }
    }

    public getEmailFrequencies(): Array<string> {
        let keys = Object.keys(this.emailFrequency);
        return keys.slice(keys.length / 2);
    };

    public customizeScorecardviewers() {
        this.modalCustomizeScorecardviewers = true;
        // this.globalInfoModel.customizeStdParticipantsList1 = this.globalInfoDataService.getCustomizeScorecardviewers();
    };

    public closeDialog() {
        this.modalCustomHierarcy = false;
        this.modalCustomizeScorecardviewers = false;
        if (!this.isEditDataFilter) {
            if (!isNullOrUndefined(this.whoCanViewParticipants)) {
                this.deSelectAllParticipants(this.whoCanViewParticipants);
                if (this.selectedHierarchy) {
                    this.setCustomHierarchy(this.whoCanViewParticipants, 'RegionKey');
                }
            }
        } else {
            this.whoCanViewParticipants = angular.copy(this.copyOfWhoCanViewParticipants);
        }
    }

    public deSelectAllParticipants(participantsList: Array<Participant>) {
        participantsList.forEach(prtcpnt => {
            prtcpnt.Status = false;
            if (!isNullOrUndefined(prtcpnt.Children)) {
                this.deSelectAllParticipants(prtcpnt.Children);
            }
        });
    };

    public setParticipantsData() {
        this.selectedParticipantsList = new Array<Participant>();
        this.prepareParticipantsData(this.whoCanViewParticipants);
        this.modalCustomHierarcy = false;
        this.modalCustomizeScorecardviewers = false;
    }

    public prepareParticipantsData(participants: Array<Participant>) {
        let selectedList: Participant[] = participants.filter(obj => {
            return obj.Status === true;
        });
        this.selectedParticipantsList = this.selectedParticipantsList.concat(selectedList);
        participants.forEach(obj => {
            if (!obj.Status && obj.Children && obj.Children.length > 0) {
                this.prepareParticipantsData(obj.Children);
            }
        });
    }

    public getDataFilterId(typeName: string): string {
        let currentDataFilter: DataFilter = this.allDataFilters.find(obj => obj.FilterName === typeName);
        return currentDataFilter.Id;
    }

    public getEstimateAmount(amountType: string): string[] {
        if (amountType === 'Between') {
            return [this.minimumAmount ? this.minimumAmount.toString() : '0', this.maximumAmount ? this.maximumAmount.toString() : '0'];
        }
        return [this.otherAmount ? this.otherAmount.toString() : '0'];
    }

    public setCheckedRegion(region: Participant) {
        region.Status = !region.Status;
        if (!isNullOrUndefined(region.Children)) {
            region.Children.forEach(division => {
                division.Status = region.Status;
                if (!isNullOrUndefined(division.Children)) {
                    division.Children.forEach(office => {
                        office.Status = region.Status;
                        if (!isNullOrUndefined(office.Children)) {
                            office.Children.forEach(resource => {
                                resource.Status = region.Status;
                            });
                        }
                    });
                }
            });
        }
    }

    public setCheckedDivision(region: Participant, division: Participant) {
        division.Status = !division.Status;
        if (!isNullOrUndefined(division.Children)) {
            division.Children.forEach(office => {
                office.Status = division.Status;
                if (!isNullOrUndefined(office.Children)) {
                    office.Children.forEach(resource => {
                        resource.Status = division.Status;
                    });
                }
            });
        }
        region.Status = region.Children.some(obj => !obj.Status) ? false : true;
    }

    public setCheckedOffice(region: Participant, division: Participant, office: Participant) {
        office.Status = !office.Status;
        if (!isNullOrUndefined(office.Children)) {
            office.Children.forEach(resource => {
                resource.Status = office.Status;
            });
        }
        division.Status = division.Children.some(obj => !obj.Status) ? false : true;
        region.Status = region.Children.some(obj => !obj.Status) ? false : true;
    }

    public setCheckedResource(region: Participant, division: Participant, office: Participant, resource: Participant) {
        resource.Status = !resource.Status;
        office.Status = office.Children.some(obj => !obj.Status) ? false : true;
        division.Status = division.Children.some(obj => !obj.Status) ? false : true;
        region.Status = region.Children.some(obj => !obj.Status) ? false : true;
    }

    public setIsEmailFrequency(emailFrequency: string) {
        if (emailFrequency) {
            this.isNotEmailFrequency = false;
        }
    }

    private prepareEmailPreferences() {
        this.emailSubscriptionList = new Array<EmailSubscription>();
        if (this.selectedParticipantsList.length > 0) {
            this.selectedParticipantsList.forEach(obj => {
                this.emailSubscriptionList.push({
                    Participant: obj,
                    Schedules: [this.emailFrequency[this.selectedPrimaryTimeFrame]]
                });
            });
        } else {
            this.emailSubscriptionList.push({
                Participant: null,
                Schedules: [this.emailFrequency[this.selectedPrimaryTimeFrame]]
            });
        }
    }

    private prepareDataFiltersData() {
        // prepare Drivability data filter
        let drivabilityMap: DataFilterMap = new DataFilterMap();
        drivabilityMap.DataFilterId = this.getDataFilterId('Drivability');
        drivabilityMap.Values = this.selectedDrivability ? [this.selectedDrivability] : ['Any'];
        this.selectedDataFilters.push(drivabilityMap);

        // prepare Repairability data filter
        let repairabilityMap: DataFilterMap = new DataFilterMap();
        repairabilityMap.DataFilterId = this.getDataFilterId('Repairability');
        repairabilityMap.Values = this.selectedRepairability ? [this.selectedRepairability] : ['Any'];
        this.selectedDataFilters.push(repairabilityMap);

        // prepare Estimating System data filter
        let estimatingSystemMap: DataFilterMap = new DataFilterMap();
        estimatingSystemMap.DataFilterId = this.getDataFilterId('Estimating System');
        estimatingSystemMap.Values = this.selectedEstimatingSystem ? [this.selectedEstimatingSystem] : ['Any'];
        this.selectedDataFilters.push(estimatingSystemMap);

        // prepare Estimate Amount data filter
        let estimateAmountMap: DataFilterMap = new DataFilterMap();
        estimateAmountMap.DataFilterId = this.getDataFilterId('Estimate Amount');
        if (this.selectedEstimateAmount) {
            estimateAmountMap.Values = [this.selectedEstimateAmount];
            estimateAmountMap.Values = estimateAmountMap.Values.concat(this.getEstimateAmount(this.selectedEstimateAmount));
        } else {
            estimateAmountMap.Values = ['Any'];
        }
        this.selectedDataFilters.push(estimateAmountMap);
    }

    private save() {
        if (this.checkedEmailPreferences) {
            this.isNotEmailFrequency = isNullOrUndefined(this.selectedPrimaryTimeFrame) ? true : false;
            if (this.isNotEmailFrequency) {
                return;
            }
            this.prepareEmailPreferences();
        }
        this.prepareDataFiltersData();
        this.dataFilterViewModel = new DataFiilterVM();
        this.dataFilterViewModel.DataFiltersMappedList = this.selectedDataFilters;
        this.dataFilterViewModel.IsSendEmail = this.checkedEmailPreferences;

        this.otherConfigDataService.saveDataFiltersData(this.dataFilterViewModel, this.emailSubscriptionList).then((res) => {
            if (res) {
                this.scorecardDataService.setCurrentScoreCardId(this.otherConfigModel.scoreCardId);
                this.scorecardDataService.getScoreCard(this.otherConfigModel.scoreCardId).then(res => {
                    if (res) {
                        this.commonEventsService.getEvent('next').next();
                    }
                });
            }
        });
    }
}

export const Otherconfig: angular.IComponentOptions = {
    template: require('./other-configurations.html'),
    controller: OtherConfigurationsController
};
