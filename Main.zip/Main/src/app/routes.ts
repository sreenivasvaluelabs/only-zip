/** @ngInject */
function httpConfig($stateProvider: ng.ui.IStateProvider, $urlRouterProvider: angular.ui.IUrlRouterProvider, $locationProvider: ng.ILocationProvider) {
    $locationProvider.html5Mode(true).hashPrefix('!');
    $urlRouterProvider.otherwise('/');

    $stateProvider
        .state('app', {
            url: '/',
            component: 'app'
        })
        .state('create-score-card', {
            url: '/create-score-card/{stage}',
            component: 'createScoreCard',
            params: { scorecardId: null }
        })
        .state('scorecardview', {
            url: '/scorecard-view',
            component: 'scorecardview'
        })
        .state('regionview', {
            url: '/region-view',
            component: 'regionview'
        });

}

export default httpConfig;
