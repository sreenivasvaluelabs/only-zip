import { browser, element, by, By, $, $$, protractor, ExpectedConditions } from 'protractor';

export class PageUtilities {
    page;

    // Set this high enough to allow the slower CICD instances enough time to process DOM changes,
    // but also low enough that if all of your tests are going to fail (maybe a required service is down),
    // that you won't be stuck sitting there for too long, either.
    private static elementTimeout = 10000;

    // protractor.ExpectedConditions
    // "Represents a library of canned expected conditions that are useful for protractor,
    // especially when dealing with non-angular apps." Also useful for verifying the absence of an
    // element, as we will see shortly. You may see other useful stuff in this library.
    private static EC = protractor.ExpectedConditions;
    private static promise = require('selenium-webdriver').promise;

    constructor() {

    }

    // waits for an element to no longer be present in the DOM.
    // Use case: when you have to wait for an element to disappear, but no
    // other elements will appear to indicate that a transition has occurred.
    // E.g. waiting for the 'Done' button to disappear, to indicate that the
    // saving is complete. There are other ways to do it, but this is the "most right" in my opinion.
    public static waitForElementToBeStale(element): Promise<{}> {
        return browser.wait(this.EC.stalenessOf(element), this.elementTimeout);
    };

    public static waitForElementToBePresent(element): Promise<{}> {
        return browser.wait(function () { return element.isPresent(); }, this.elementTimeout);
    };

    public static waitForElementToBeDisplayed(element): Promise<{}> {
        browser.wait(function () { return element.isPresent(); }, this.elementTimeout);
        return browser.wait(function () { return element.isDisplayed(); }, this.elementTimeout);
    };

    public static waitForElementToBeEnabled(element): Promise<{}> {
        browser.wait(function () { return element.isPresent(); }, this.elementTimeout);
        browser.wait(function () { return element.isDisplayed(); }, this.elementTimeout);
        return browser.wait(function () { return element.isEnabled(); }, this.elementTimeout);
    };
};
