import { browser, element, by, By, $, $$, protractor, ElementFinder } from 'protractor';

export class ComponentPage {
    public yesDogComponent(): ElementFinder {
        return element(By.id('mi-component-yesdog'));
    }

    public yesDogToggle(): ElementFinder {
        return element(By.id('mi-component-yesdog__dog-toggle'));
    }

    public yesDogPupElement(dogid: number): ElementFinder {
        return element(By.id('mi-component-yesdog__dog-' + dogid));
    }
}
